# sensorApp/views.py

import json
import requests

from datetime import timedelta

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserChangeForm
from django.contrib.auth.views import LoginView
from django.core.mail import send_mail
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.utils.timezone import now
from django.views.decorators.csrf import csrf_exempt

from .models import SensorData, Alert, Feedback
from .forms import FeedbackForm, SignupForm


# ─────────────────────────────────────────────────────────────
# Global alert cooldown
# ─────────────────────────────────────────────────────────────

_last_email_time = None


# ─────────────────────────────────────────────────────────────
# Alert helper
# ─────────────────────────────────────────────────────────────

def _check_alert(data):

    if data and data.soil < 1000 and data.distance > 5:
        return f"🚨 Soil is dry! Soil={data.soil}, Distance={data.distance} cm"

    return None


# ─────────────────────────────────────────────────────────────
# ThingSpeak auto fetch
# ─────────────────────────────────────────────────────────────

def _maybe_fetch_thingspeak():

    latest = SensorData.objects.order_by('-created_at').first()

    if not latest:
        SensorData.fetch_from_thingspeak()

    else:
        age = (now() - latest.created_at).total_seconds()

        if age > 60:
            SensorData.fetch_from_thingspeak()


# ═════════════════════════════════════════════════════════════
# PUBLIC PAGES
# ═════════════════════════════════════════════════════════════

def home_view(request):
    return render(request, 'base.html')


def about_view(request):
    return render(request, 'sensor/about.html')


def feedback_view(request):

    if request.method == 'POST':

        form = FeedbackForm(request.POST)

        if form.is_valid():
            form.save()

            messages.success(
                request,
                'Thank you! Your feedback has been submitted.'
            )

            return redirect('sensorApp:feedback_thanks')

    else:
        form = FeedbackForm()

    return render(
        request,
        'feedback/feedback.html',
        {'form': form}
    )


def feedback_thanks_view(request):
    return render(request, 'feedback/feedback_thanks.html')


# ═════════════════════════════════════════════════════════════
# AUTHENTICATION
# ═════════════════════════════════════════════════════════════

def signup_view(request):

    if request.method == 'POST':

        form = SignupForm(request.POST)

        if form.is_valid():

            user = form.save()

            login(request, user)

            messages.success(
                request,
                'Account created successfully.'
            )

            return redirect('sensorApp:sensorDashboard')

    else:
        form = SignupForm()

    return render(
        request,
        'registration/signup.html',
        {'form': form}
    )


class SensorLoginView(LoginView):

    template_name = 'registration/login.html'

    def get_success_url(self):

        user = self.request.user

        if user.is_superuser or user.is_staff:
            return '/admin/'

        return '/sensor/'

    def form_valid(self, form):

        messages.success(
            self.request,
            'Login successful.'
        )

        return super().form_valid(form)


def logout_view(request):

    logout(request)

    messages.success(
        request,
        'Logged out successfully.'
    )

    return redirect('sensorApp:login')


# ═════════════════════════════════════════════════════════════
# PROFILE
# ═════════════════════════════════════════════════════════════

@login_required
def profile_view(request):
    return render(request, 'account/profile.html')


@login_required
def edit_profile_view(request):

    if request.method == 'POST':

        form = UserChangeForm(
            request.POST,
            instance=request.user
        )

        if form.is_valid():

            form.save()

            messages.success(
                request,
                'Profile updated successfully.'
            )

            return redirect('sensorApp:profile')

    else:

        form = UserChangeForm(instance=request.user)

    return render(
        request,
        'account/edit_profile.html',
        {'form': form}
    )


# ═════════════════════════════════════════════════════════════
# SENSOR DASHBOARD
# ═════════════════════════════════════════════════════════════

@login_required
def dashboard(request):

    _maybe_fetch_thingspeak()

    data = SensorData.objects.order_by('-created_at').first()

    history = SensorData.objects.order_by('-created_at')[:10]

    context = {
        'data': data,
        'history': history,
        'alert': _check_alert(data),
    }

    return render(
        request,
        'sensor/dashboard.html',
        context
    )


# ═════════════════════════════════════════════════════════════
# SENSOR HISTORY PAGE
# ═════════════════════════════════════════════════════════════

@login_required
def history_view(request):

    records = SensorData.objects.order_by('-created_at')

    return render(
        request,
        'sensor/history.html',
        {
            'records': records
        }
    )


# ═════════════════════════════════════════════════════════════
# ALERT HISTORY PAGE
# ═════════════════════════════════════════════════════════════

@login_required
def alert_history(request):

    alerts = Alert.objects.order_by('-created_at')

    return render(
        request,
        'sensor/alerts.html',
        {
            'alerts': alerts
        }
    )


# ═════════════════════════════════════════════════════════════
# SENSOR API
# ═════════════════════════════════════════════════════════════

@csrf_exempt
def sensor_api(request):

    global _last_email_time

    if request.method == 'POST':

        try:

            body = json.loads(request.body)

            distance = float(body.get('distance', 0))

            soil = float(body.get('soil', 0))

            temperature = float(body.get('temperature', 0))

            humidity = float(body.get('humidity', 0))

            record = SensorData.objects.create(
                distance=distance,
                soil=soil,
                temperature=temperature,
                humidity=humidity,
            )

            alert_msg = _check_alert(record)

            if alert_msg:

                Alert.objects.create(
                    distance=distance,
                    soil=soil,
                    message=alert_msg
                )

                current_time = now()

                if (
                    _last_email_time is None or
                    (current_time - _last_email_time)
                    > timedelta(minutes=5)
                ):

                    recipient = (
                        request.user.email
                        if request.user.is_authenticated
                        and request.user.email
                        else getattr(settings, 'EMAIL_HOST_USER', '')
                    )

                    if recipient:

                        send_mail(
                            subject='🚨 Soil Dry Alert!',
                            message=alert_msg,
                            from_email=getattr(
                                settings,
                                'EMAIL_HOST_USER',
                                ''
                            ),
                            recipient_list=[recipient],
                            fail_silently=True,
                        )

                    _last_email_time = current_time

            return JsonResponse({
                'status': 'success',
                'alert': alert_msg
            })

        except Exception as e:

            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=400)

    return JsonResponse({
        'error': 'Only POST allowed'
    }, status=405)


# ═════════════════════════════════════════════════════════════
# LATEST SENSOR DATA
# ═════════════════════════════════════════════════════════════

def latest_data(request):

    _maybe_fetch_thingspeak()

    data = SensorData.objects.order_by('-created_at').first()

    if not data:

        return JsonResponse({
            'distance': 0,
            'soil': 0,
            'temperature': 0,
            'humidity': 0,
            'time': 'No data yet',
        })

    return JsonResponse({

        'distance': data.distance,

        'soil': data.soil,

        'temperature': data.temperature,

        'humidity': data.humidity,

        'time': data.created_at.strftime('%H:%M:%S'),

        'alert': _check_alert(data),

    })


# ═════════════════════════════════════════════════════════════
# CHART DATA
# ═════════════════════════════════════════════════════════════

def chart_data(request):

    qs = list(
        SensorData.objects.order_by('-created_at')[:20]
    )

    qs.reverse()

    return JsonResponse({

        'labels': [
            d.created_at.strftime('%H:%M:%S')
            for d in qs
        ],

        'distance': [
            d.distance
            for d in qs
        ],

        'soil': [
            d.soil
            for d in qs
        ],

        'temperature': [
            d.temperature
            for d in qs
        ],

        'humidity': [
            d.humidity
            for d in qs
        ],
    })


# ═════════════════════════════════════════════════════════════
# WEATHER API
# ═════════════════════════════════════════════════════════════

def weather_api(request):

    city = request.GET.get('city', 'Belgaum')

    api_key = getattr(settings, 'WEATHER_API_KEY', None)

    if not api_key:

        return JsonResponse({
            'error': 'Weather API key missing.'
        })

    url = (
        'https://api.openweathermap.org/data/2.5/weather'
        f'?q={city}&appid={api_key}&units=metric'
    )

    try:

        resp = requests.get(url, timeout=10)

        data = resp.json()

        if resp.status_code == 200:

            return JsonResponse({

                'city': data.get('name', city),

                'temperature': data['main']['temp'],

                'humidity': data['main']['humidity'],

                'weather': data['weather'][0]['description'],

                'rain': data.get('clouds', {}).get('all', 0),

            })

        return JsonResponse({
            'error': data.get(
                'message',
                'Weather unavailable'
            )
        })

    except Exception as e:

        return JsonResponse({
            'error': f'Could not load weather: {e}'
        })