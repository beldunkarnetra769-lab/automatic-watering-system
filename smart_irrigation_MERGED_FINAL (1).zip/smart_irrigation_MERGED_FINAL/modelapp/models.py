# modelapp/models.py
from django.db import models


class IrrigationPrediction(models.Model):
    soil_type = models.CharField(max_length=50)
    crop_type = models.CharField(max_length=50)
    temperature = models.FloatField()
    humidity = models.FloatField()
    rainfall = models.FloatField()
    water_availability = models.CharField(max_length=20)
    result = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.crop_type} | {self.result} | {self.created_at.strftime('%Y-%m-%d')}"
