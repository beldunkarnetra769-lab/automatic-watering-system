# myapp/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import Group

from .models import CustomUser, Feedback, Message

admin.site.site_header = "Smart Irrigation System Admin"
admin.site.site_title = "Smart Irrigation Admin"
admin.site.index_title = "Welcome to Smart Irrigation Dashboard"


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    model = CustomUser
    list_display = ('email', 'name', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active', 'gender')
    search_fields = ('email', 'name')
    ordering = ('email',)
    fieldsets = (
        (None, {'fields': ('username', 'email', 'password')}),
        ('Personal Info', {'fields': ('name', 'contact', 'age', 'gender', 'profile_pic')}),
        ('Permissions', {'fields': ('is_staff', 'is_active', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ['user', 'created_at', 'resolved']
    list_filter = ['resolved']
    search_fields = ['user__name', 'message']
    ordering = ['-created_at']
    actions = ['mark_resolved']

    def mark_resolved(self, request, queryset):
        updated = queryset.update(resolved=True)
        self.message_user(request, f"{updated} feedback(s) marked as resolved.")
    mark_resolved.short_description = "Mark selected feedback as resolved"


@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display = ('id', 'sender', 'receiver', 'timestamp', 'is_group_message')
    search_fields = ('sender__email', 'receiver__email', 'text')
    list_filter = ('is_group_message', 'timestamp')
    readonly_fields = ('timestamp',)
    ordering = ['-timestamp']


admin.site.unregister(Group)
