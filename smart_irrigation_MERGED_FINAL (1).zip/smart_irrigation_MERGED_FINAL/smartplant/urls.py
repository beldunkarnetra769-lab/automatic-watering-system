from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('myapp.urls')),
    path('modelapp/', include('modelapp.urls')),
    path('', include('sensorApp.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
