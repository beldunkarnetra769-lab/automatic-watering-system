"""
Django settings for smartplant project (Smart Irrigation System - MERGED).
FILE 1 UI + FILE 2 Working Backend.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-hwy(4jr!0j0h^_db&oa%z_q()g3vqz9q@4&%4#gn1a6q4nsa)q'

DEBUG = True

ALLOWED_HOSTS = ['*']

AUTH_USER_MODEL = 'myapp.CustomUser'

INSTALLED_APPS = [
    'jazzmin',  # Custom admin theme

    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'myapp',
    'modelapp',
    'sensorApp',

    'crispy_forms',
    'crispy_bootstrap5',
    'widget_tweaks',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'smartplant.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'smartplant.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

# ── Static & Media ──────────────────────────────────────────────────────────
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# ── Auth redirects ───────────────────────────────────────────────────────────
LOGIN_URL = 'login'
LOGOUT_REDIRECT_URL = 'login'
LOGIN_REDIRECT_URL = 'dashboard'

# ── Crispy Forms ─────────────────────────────────────────────────────────────
CRISPY_ALLOWED_TEMPLATE_PACKS = 'bootstrap5'
CRISPY_TEMPLATE_PACK = 'bootstrap5'

# ── Email ─────────────────────────────────────────────────────────────────────
# For development: prints emails to console.
# Change to smtp.EmailBackend and fill credentials for production.
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your@gmail.com'      # ← replace with your Gmail
EMAIL_HOST_PASSWORD = 'your-app-password'  # ← use Gmail App Password
DEFAULT_FROM_EMAIL = 'your@gmail.com'
ADMINS = [('Site Admin', 'admin@example.com')]

# ── Weather API (OpenWeatherMap) ─────────────────────────────────────────────
WEATHER_API_KEY = 'e2400e19bee1aca993767a7e6b1eea01'

# ── ThingSpeak (IoT live data) ───────────────────────────────────────────────
THINGSPEAK_API_KEY = 'RZJFAUFNYENLCFC3'
THINGSPEAK_CHANNEL_ID = '3377240'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
